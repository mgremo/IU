package es.ucm.fdi.iu.model;

public class Views {
	public static class Public {}
}
