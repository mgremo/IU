package es.ucm.fdi.iu.model;

public class Set extends Params {
	private String[] names;

	public String[] getNames() {
		return names;
	}

	public void setNames(String[] names) {
		this.names = names;
	}
}
